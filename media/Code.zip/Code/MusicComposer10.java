//34567890123456789012345678901234567890123456789012345678901234567890123456789
/*File MusicComposer10.java
Copyright 2014, R.G.Baldwin
Revised 08/23/14

This is a general purpose audio graph program that reads an input text file 
containing numeric values for y as a function of equally spaced values for x 
and produces an output melody that represents a graph of that data. The values
for y are read as a comma-delimited list of values and are treated as type 
double. The name of the text file is input as a command-line parameter.

Additional details will be found in the class named AudioGraph01.

This program requires the following classes:

AudioGraph01
AudioSignalGenerator02
AudioPlayOrFile01
AudioFormatParameters01

The sound can be played immediately or can be saved in an audio file of 
type AU for playback later. You should be able to play the audio file with any
standard media player that can handle the AU file type

Tested using JDK 1.8 under Win 7.
******************************************************************************/

public class MusicComposer10{
  //Instantiate an object containing audio format parameters with predefined
  // values. They may be modified by the signal generator at runtime. Values
  // allowed by Java SDK 1.4.1 are shown in comments in the class definition.
  AudioFormatParameters01 audioParams = new AudioFormatParameters01();
  
  //A buffer to hold the audio data that will be played or filed.
  byte[] melody;
  
  //A place to store the incoming args array.
  String[] args; 
  //-------------------------------------------------------------------------//

  //Command-line parameter (three parameters required)
  //0 - If "play", the sound will be played immediately. Otherwise, the string
  //    will be used as a filename for an audio file of type AU. In the latter
  //    case, it must be a string that would be valid as a file name for the 
  //    operating system in use. 
  //1 - Output pulses per second 
  //2 - Input file name
  public static void main(String[] args){
    //Instantiate a new object of this class.
    new MusicComposer10(args);
  }//end main
  //-------------------------------------------------------------------------//
  
  public MusicComposer10(String[] args){//constructor
    //Save the args array.
    this.args = args;
    
    //Create default args data if no args data is provided on the command line.
    if(args.length == 0){
      this.args = new String[3];
      this.args[0] = "play";//Play the melody immediately
      this.args[1] = "6";//Pulses per minute
      this.args[2] = "TestData01.txt";
    }//end if

    //Get a populated array containing audio data.
    AudioGraph01 audioGraph01 = new AudioGraph01(audioParams,this.args,melody);
    melody = audioGraph01.getMelody();

    //Play or file the audio data
    new AudioPlayOrFile01(audioParams,melody,this.args[0]).playOrFileData();
  }//end constructor
  //-------------------------------------------------------------------------//
}//end class MusicComposer10.java
//===========================================================================//

