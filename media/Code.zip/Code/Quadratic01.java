//34567890123456789012345678901234567890123456789012345678901234567890123456789
/*File Quadratic01.java
Copyright 2014, R.G.Baldwin
Revised 08/31/14

This program produces an output text file containing values for y as a function
of x. The contents of the text file can be converted to audio and either played
or written into an audio file of type AU for playback later by the program 
named AudioGraph01.

Function:
y = x*x -2*x -15 
This is a quadratic equation with two real roots at -5 and +3.

To modify this program to handle other functions, you only need to modify the 
instance variables in the class named Runner and modify the code in the method 
named getYval.

Tested using Java SE 8 under Win 7
******************************************************************************/

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Quadratic01{//Driver class
  public static void main(String[] args){
    //Do not modify the code in this method.
    Runner obj = new Runner();
    obj.run();
  }//end main
}//end class Quadratic01
//============================================================================/

class Runner{
  //Modify the following instance variables as needed. 
  double xMin = -10;//Minimum value for x
  double xMax = 10;//Maxamum value for x
  double xInc = 0.5;//Used to determine x-values for evaluation of y-value

  String fileName = "Data/Quadratic01.txt";//Output file name in Data folder
  
  void run(){
    //Do not modify the code in this method.
    double xVal = xMin;
    String outString = "";
    while(xVal <= xMax){
      //Construct an output string contain comma-separated values of y as a
      // function of x.
      outString += getYval(xVal) + ",";
      //Increment x
      xVal += xInc;
    }//end while loop
    
    writeOutputFile(fileName,outString);
    
  }//end run method
  //-------------------------------------------------------------------------//
  
  //This method evaluates the function. Modify it to evaluate different 
  // functions.
  //Function:
  //y = x*x -2*x -15 
  //This is a quadratic equation with two real roots at -5 and +3.
  double getYval(double xVal){
    //Evaluate the function here
    double result = xVal*xVal - 2*xVal -15;
    
    //Limit the return value to three decimal digits
    return (Math.rint(1000.0*result))/1000.0;
  }//end getY
  //-------------------------------------------------------------------------//
  
  //This method writes the output file. Do not modify this method.
  void writeOutputFile(String fileName,String outString){
    try{
      File file = new File(fileName);
       //if the file doesn't exists, create it. If it does exist, overwrite it.
      if (!file.exists()) {
        file.createNewFile();
      }//end if
      FileWriter fileWriter = new FileWriter(file.getAbsoluteFile());
      BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
      bufferedWriter.write(outString);      
      bufferedWriter.close();
    }catch (IOException e) {
      e.printStackTrace();
    }//end catch
  }//end writeOutputFile
  //-------------------------------------------------------------------------//
}//end class Runner