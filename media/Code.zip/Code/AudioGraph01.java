//34567890123456789012345678901234567890123456789012345678901234567890123456789
/*File AudioGraph01.java
Copyright 2014, R.G.Baldwin
Revised 08/31/14

This is a general purpose audio graph program that reads an input text file 
containing numeric values for y as a function of equally spaced values for x 
and produces an output melody that represents a graph of that data. The values
for y are read as a comma-delimited list of values and are treated as type 
double. The name of the text file is input as a command-line parameter.

The text file must be stored in a subfolder named Data that is a child of the 
folder containing the compiled program. The text file may be created manually 
using a simple text editor or may be created as the output of a program that 
evaluates a function. Space characters are not allowed in the data.

The program ignores:
 Blank lines that result in a string with a zero length
 Comment lines that begin with a /
 Lines that begin with a space

The data is biased and scaled so as to make maximum use of the audio dynamic 
range from 220 Hz to 1760 Hz. If the data contains both positive and negative 
values, the data is adjusted so that the most negative value is emitted at 
220 Hz and the most positive value is emitted at 1760 Hz. The frequency that 
represents zero will fall somewhere between those extremes. A unique sound 
is heard whenever a value of zero occurs in the data. It consists of a weighted
sum of three frequencies one octave apart centered on the frequency
that represents zero. 

Three data items with a value of zero are prepended onto the incoming data. 
They are used to establish the audio pitch for a value of zero.

If the data is all positive, it is biased and scaled so that the minimum value 
is emitted at 220 Hz and the maximum value is emitted at 1760 Hz. In this case,
the frequency that represents zero has little meaning because it is off the 
bottom of the page, so to speak. It is set at 220 Hz.

An output pulse is heard for each data value. The frequency of the pulse is 
proportional to the data value. Higher data values result in pulses with a 
higher pitch. Lower data values result in pulses with a lower pitch.

The output pulse rate in pulses per second is specified by the user as a 
command-line parameter. Faster output rates provide a quick look at the data. 
Slower output rates allow for more detailed audio analysis of the data. 

To eliminate the pops and clicks that result from abrupt changes in frequence 
from one pulse to the next, each pulse is shaped using a linear scale factor 
that is zero at both ends of the pulse and maximum at the center of the pulse.

Sound progresses from the left speaker to the right speaker in proportion to 
the value of x as a percentage of the total number of x values.

The number, type, and order of command-line parameters are defined in the 
comments in the class named MusicComposer10.

Tested using Java SE with Windows 7.
******************************************************************************/

import java.io.*;
import java.nio.*;
import java.util.*;

public class AudioGraph01 extends AudioSignalGenerator02{
  
  double[] inputData;
  double highFreq = 1760;
  double lowFreq = 220;
  
  public AudioGraph01(AudioFormatParameters01 audioParams,
               String[] args,
               byte[] melody){
    super(audioParams,args,melody);
    
    
    //Read the input file to define the function that is to be played or
    // filed. It must be stored in the subfolder named Data. The data is
    // initially stored in an ArrayList object for convenience and later
    // transferred to an array object.
    String fileName = args[2];
    try{
      ArrayList dataList = new ArrayList();
      BufferedReader in = new BufferedReader(
                                           new FileReader("Data/" + fileName));
      String str;
      while ((str = in.readLine()) != null) {

        //Split the input string into multiple substrings using the comma as
        // the delimiter and save them in an array object.
        String[] strArr = str.split(",");

        //Ignore:
        // Blank lines that result in a string with a zero length
        // Comments that begin with a /
        // Lines that begin with a space
        if(strArr[0].length() == 0){
          System.out.println("Blank line will be ignored");
        }else if(strArr[0].substring(0,1).equals("/")){
          System.out.println("Comment:  " + Arrays.toString(strArr));
        }else if(strArr[0].substring(0,1).equals(" ")){
          System.out.println("Ignore line that begins with space: " + 
                                                      Arrays.toString(strArr));
        }else{
          //Apparently good data. Add the contents of the array to the end of
          // the ArrayList object, one substring (element) at a time.
          for(int cnt = 0;cnt < strArr.length;cnt++){
            dataList.add(Double.parseDouble(strArr[cnt]));
          }//end for loop
        }//end else
      }//end while
      in.close();//close the input file
      
      //Move the contents of dataList from the ArrayList object to the
      // inputData array. Make the array three elements longer than the size
      // of the ArrayList object to accommodate prepending three elements with
      // a value of zero.
      inputData = new double[dataList.size()+3];
      int count = 0;
      
      //Prepend three data items with a value of zero to the array. They will
      // be used to establish the audio pitch for a value of zero.
      inputData[count++] = 0;
      inputData[count++] = 0;
      inputData[count++] = 0;
      
      Iterator iter = dataList.iterator();
      while(iter.hasNext()){
        double value = (double)iter.next();
        inputData[count++] = value;
      }//end while loop

    }catch(Exception ex){
      ex.printStackTrace();
    }//end catch
  }//end constructor
  //-------------------------------------------------------------------------//
  
  //This method reads an array containing data values and produces an array of
  // output audio data that relates the data values to frequency or pitch.
  // One output pulse is produced for each data value. The output rate in
  // pulses per second is provided by the user as a command-line parameter.
  //The audio output can be thought of as an audio representation of a graph
  // of the input data with three zero values prepended onto the front to
  // establish the pitch for a y value of zero.
  
  byte[] getMelody(){
    //Set channels to 2 for stereo overriding the default value of 1.
    audioParams.channels = 2;

    //Each channel requires two 8-bit bytes per 16-bit sample.
    int bytesPerSampPerChan = 2;
    
    //Override the default sampleRate of 16000.0F. Allowable sample rates
    // are 8000,11025,16000,22050, and 44100 samples per second.
    audioParams.sampleRate = 8000.0F;
    
    //Declare variables used to control the output volume on the left and
    // right speaker channels. These values will be used to cause pulses
    // representing the data values to progress uniformly from the left
    // speaker to the right speaker in proportion to the value of x.
    double gain = 0.0;
    double leftGain = 0.0;
    double rightGain = 0.0;

    //Declare a variable that is used to control the frequency of each pulse.
    double freq = 0.0;

    //Set the length of each pulse in seconds and in samples. The user
    // specifies the output rate in pulses per second as a command-line
    // parameter. The pulse length in seconds is the reciprocal of that value.
    double pulseLengthInSec = 1/Double.parseDouble(args[1]);//in seconds
    int pulseLengthInSamples = (int)(pulseLengthInSec*audioParams.sampleRate);
    
    //Create an output array of sufficient size to contain the audio data.
    melody = new byte[(int)(inputData.length * 
                            pulseLengthInSamples * 
                            bytesPerSampPerChan * 
                            audioParams.channels)];
    System.out.println("melody.length = " + melody.length);
    
    //Prepare a ByteBuffer for use
    byteBuffer = ByteBuffer.wrap(melody);
    
    double freqRange = highFreq - lowFreq;
    
    //Determine the minimum and maximum data values. These values will be used
    // to bias and scale the data so as to make maximum use of the available
    // audio dynamic range from 220 Hz to 1760 Hz.
    double highData = Double.MIN_VALUE;
    double lowData = Double.MAX_VALUE;
    //Skip first three values which are always zero.
    for(int cnt = 3;cnt < inputData.length;cnt++){
      if (inputData[cnt] > highData){
        highData = inputData[cnt];
      }//end if
      if(inputData[cnt] < lowData){
        lowData = inputData[cnt];
      }//end if
    }//end for loop

    double dataRange = highData - lowData;
  
    //Determine the value that will represent a y-value of 0. Also, if the
    // data is all positive, bias the data values so that the lowest value
    // will sound at 220Hz and the highest value will sound at 1760 Hz.
    double zeroFreq;
    if(lowData >= 0.0){
      //Bias all data so that the lowest value will display at 220Hz. Skip the
      // first three data values which are always zero.
      for(int cnt = 3;cnt < inputData.length;cnt++){
        inputData[cnt] -= lowData;
      }//end for loop
      
      //zeroFreq has little meaning in this case because it is probably off the
      // bottom of the page. Set it to the bottom of the range.
      zeroFreq = lowFreq;
    }else{
      //Set zeroFreq to a value that represents a value of zero for bipolar
      // data.
      zeroFreq = lowFreq +(Math.abs(lowData)/dataRange) * freqRange;
    }//end else
    System.out.println("zeroFreq = " + zeroFreq);

    //Compute the audio sample values and deposit them in the output melody
    // array.
    int sampLength = melody.length/audioParams.channels/bytesPerSampPerChan;

    for(int cnt = 0; cnt < sampLength; cnt++){
      //Compute the time in seconds for this sample.
      double time = cnt/audioParams.sampleRate;
      
      double yValue = 0;
      if(cnt%pulseLengthInSamples == 0){
        //It is time for a new pulse. Get the next y value from the data array
        // and use it to compute the frequency of the next pulse.
        yValue = inputData[cnt/pulseLengthInSamples];
        freq = zeroFreq + (yValue/dataRange)*freqRange;
      }//end if

      //Deposit audio data in the melody array for each channel. Shape the
      // amplitude of each pulse with a triangular scale factor (rooftop shape)
      // to  minimize the undesirable pops and clicks that occur when there
      // are abrupt change in the frequency from one pulse to the next. The 
      // following gain factor ranges from 0.0 at the ends to maximum in the
      // center of the pulse.
      gain = (cnt%pulseLengthInSamples)/(double)pulseLengthInSamples;

      if(gain > 0.5){
        //Change to a negative slope.
        gain = (pulseLengthInSamples - 
                        cnt%pulseLengthInSamples)/(double)pulseLengthInSamples;
      }//end if
   
      //Set the final gain to a value that is compatible with 16-bit audio
      // data.
      gain = 8000*gain;

      //Cause the sound to progress from the left speaker to the right speaker
      // in proportion to the value of x.
      rightGain = gain * ((double)cnt/sampLength);
      leftGain = gain - rightGain;

      if(freq == zeroFreq){
        //Compute scaled pulse values and deposit them into the melody. Mark
        // the zeroFreq by adding frequency components at a reduced level one
        // octave above and one octave below the zeroFreq. This will make it
        // sound special in the output.
        byteBuffer.putShort((short)(leftGain*Math.sin(2*Math.PI*freq*time) + 
                              (leftGain*Math.sin(2*2*Math.PI*freq*time))/3 + 
                              (leftGain*Math.sin(2*Math.PI*freq*time/2))/3));
        byteBuffer.putShort((short)(rightGain*Math.sin(2*Math.PI*freq*time) + 
                              (rightGain*Math.sin(2*2*Math.PI*freq*time))/3 + 
                              (rightGain*Math.sin(2*Math.PI*freq*time/2))/3));
      }else{
        //Compute scaled pulse values and deposit them into the melody.
        byteBuffer.putShort((short)(leftGain*Math.sin(2*Math.PI*freq*time)));
        byteBuffer.putShort((short)(rightGain*Math.sin(2*Math.PI*freq*time)));
      }//end else
    }//end for loop
    
    return melody;
  }//end method getMelody
  //-------------------------------------------------------------------------//

}//end class AudioGraph01
//===========================================================================//