//34567890123456789012345678901234567890123456789012345678901234567890123456789
/*File AudioSignalGenerator02.java
Copyright 2014, R.G.Baldwin
Revised 08/19/14

This is an abstract class that serves as the the base class for several other 
classes that can be used to create melodies of different types.
******************************************************************************/

import java.io.*;
import java.nio.*;
import java.util.*;

public abstract class AudioSignalGenerator02{
  
  //Note:  This class can only be used to generate signed 16-bit data.
  ByteBuffer byteBuffer;
  String[] args;
  byte[] melody;
  AudioFormatParameters01 audioParams;
  //-------------------------------------------------------------------------//
  
  //Constructor
  public AudioSignalGenerator02(AudioFormatParameters01 audioParams,
                                String[] args,
                                byte[] melody){
    this.audioParams = audioParams;
    this.args = args;
    this.melody = melody;
  }//end constructor
  //-------------------------------------------------------------------------//

  //The following abstract method must be overridden in a subclass for this
  // class to be of any value.
  abstract byte[] getMelody();
}//end AudioSignalGenerator02
//===========================================================================//
