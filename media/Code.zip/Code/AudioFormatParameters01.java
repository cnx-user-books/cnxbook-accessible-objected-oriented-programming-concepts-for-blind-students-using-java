//34567890123456789012345678901234567890123456789012345678901234567890123456789
/*File AudioFormatParameters01.java
Copyright 2014, R.G.Baldwin
Revised 08/16/14
******************************************************************************/

public class AudioFormatParameters01{
  //The following are audio format parameters used by the Java audio system.
  // They may be modified by the signal generator at runtime.  Values allowed
  // by Java SDK 1.4.1 are shown in comments.
  public float sampleRate = 16000.0F;
  //Allowable 8000,11025,16000,22050,44100
  public int sampleSizeInBits = 16;
  //Allowable 8,16
  public int channels = 1;
  //Allowable 1,2
  public boolean signed = true;
  //Allowable true,false
  public boolean bigEndian = true;
  //Allowable true,false
}//end class AudioFormatParameters01
//===========================================================================//