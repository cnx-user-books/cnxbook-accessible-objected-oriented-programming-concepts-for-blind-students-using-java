//34567890123456789012345678901234567890123456789012345678901234567890123456789
/*File AudioPlayOrFile01.java
Copyright 2014, R.G.Baldwin
Revised 08/16/14
******************************************************************************/
import javax.sound.sampled.*;
import java.io.*;
import java.util.*;

public class AudioPlayOrFile01{
  //An object of this class is used to either play the sound in the array
  // named melody or to write it into an audio file of type AU.
  
  //The following are general instance variables used to create a
  // SourceDataLine object.
  AudioFormat audioFormat;
  AudioInputStream audioInputStream;
  SourceDataLine sourceDataLine;

  AudioFormatParameters01 audioParams;
  byte[] melody;
  String playOrFile;//"play" to play immediately or a fileName to write
                    // an output file of type AU.
  //-------------------------------------------------------------------------//
  
  public AudioPlayOrFile01(AudioFormatParameters01 audioParams,
                           byte[] melody,
                           String playOrFile){//constructor

    this.audioParams = audioParams;
    this.melody = melody;
    this.playOrFile = playOrFile;
  }//end constructor
  //-------------------------------------------------------------------------//

  //This method plays or files the synthetic audio data that has been generated
  // and saved in an array.
  void playOrFileData() {
    try{
      //Get an input stream on the byte array containing the data
      InputStream byteArrayInputStream = new ByteArrayInputStream(melody);

      //Get the required audio format
      audioFormat = new AudioFormat(audioParams.sampleRate,
                                    audioParams.sampleSizeInBits,
                                    audioParams.channels,
                                    audioParams.signed,
                                    audioParams.bigEndian);

      //Get an audio input stream from the ByteArrayInputStream
      audioInputStream = new AudioInputStream(
                                     byteArrayInputStream,
                                     audioFormat,
                                     melody.length/audioFormat.getFrameSize());

      //Get info on the required data line
      DataLine.Info dataLineInfo = new DataLine.Info(SourceDataLine.class,
                                                     audioFormat);

      //Get a SourceDataLine object
      sourceDataLine = (SourceDataLine)AudioSystem.getLine(dataLineInfo);
                                   
      //Decide whether to play the audio data immediately, or to write it
      // into an audio file of type AU based on the incoming parameter named
      // playOrFile.
      if(playOrFile.toUpperCase().equals("PLAY")){
        //Create a thread to play back the data and start it running.  It will
        // run until all the data has been played back
        new PlayAudioThread().start();
      }else{
        //Write the data to an output file with the name provided by the
        // incoming parameter named playOrFile.
        try{
          AudioSystem.write(audioInputStream,
                            AudioFileFormat.Type.AU,
                            new File(playOrFile + ".au"));
        }catch (Exception e) {
          e.printStackTrace();
          System.exit(0);
        }//end catch
      }//end else
    }catch (Exception e) {
      e.printStackTrace();
      System.exit(0);
    }//end catch
  }//end playOrFileData
//===========================================================================//

  //Inner class to play back the data that was saved.
  class PlayAudioThread extends Thread{
    //This is a working buffer used to transfer the data between the
    // AudioInputStream and the SourceDataLine.  The size is rather arbitrary.
    byte playBuffer[] = new byte[16384];
  
    public void run(){
      try{
        //Open and start the SourceDataLine
        sourceDataLine.open(audioFormat);
        sourceDataLine.start();
  
        int cnt;
        //Get beginning of elapsed time for playback
        long startTime = new Date().getTime();
  
        //Transfer the audio data to the speakers
        while((cnt = audioInputStream.read(
                                       playBuffer,0,playBuffer.length)) != -1){
          //Keep looping until the input read method returns -1 for empty
          // stream.
          if(cnt > 0){
            //Write data to the internal buffer of the data line where it will
            // be delivered to the speakers in real time
            sourceDataLine.write(playBuffer, 0, cnt);
          }//end if
        }//end while
  
        //Block and wait for internal buffer of the SourceDataLine to become
        // empty.
        sourceDataLine.drain();
  
  
        //Get and display the elapsed time for the previous playback.
        int elapsedTime = (int)(new Date().getTime() - startTime);
        System.out.println("Elapsed time: " + elapsedTime);
  
        //Finish with the SourceDataLine
        sourceDataLine.stop();
        sourceDataLine.close();
      }catch (Exception e) {
        e.printStackTrace();
        System.exit(0);
      }//end catch
  
    }//end run
  }//end inner class PlayAudioThread
  //=========================================================================//
}//end AudioPlayOrFile01 class